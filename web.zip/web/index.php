<?php
echo "<h1>ZeroSubBlog</h1>";
echo "<p>Bienvenue sur le blog interne de ZeroTech.</p>";
echo "<p><a href='article.php?id=1'>Article 1</a></p>";
echo "<p><a href='article.php?id=2'>Article 2</a></p>";
echo "<p><a href='page.php?page=home.php'>Page interne</a></p>";
