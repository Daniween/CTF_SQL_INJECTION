<?php
echo "<p>Page interne : home</p>";
echo "<p>Un admin a laissé une note dans /admin/flag.txt</p>";
